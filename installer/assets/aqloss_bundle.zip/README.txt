Placeholder bundle. Replaced by package-windows.ps1 during CI packaging.
